﻿
Please follow these steps to install and launch the SKCCLogger on your Ubuntu LINUX PC. 

1. Using the Files application navigate to your downloads directory.

2. Double click on the downloaded SKCCLogger_Linux.zip file, press the extract button at the top left of the Archive manager screen. From the Archive Manager screen select the Home button in the left panel, then the Extract button at the bottom left, this should extract the application files into a folder called SKCCLogger_Linux in your Home directory, once the extract is finished press the Quit button, this will return you to the File application.

3. (ONLY IF INITIAL INSTALLATION - NOT FOR UPGRADE) Using the Files application, navigate to your Documents directory, right click in the window and select New Folder to create a SKCCLogger directory.

4. Using Files application navigate to the SKCCLogger_Linux folder in your home directory, from here select the following files (note: hold Ctrl and then click to select multiple files):
   -- Logs folder (ONLY IF INITIAL INSTALLATION - NOT FOR UPGRADE)
   -- DXCC_Entity_DB.rsd
   -- SKCCData_DB.sql
   -- SKCCLogger User Guide.pdf
   -- SKCCLogger.ini (ONLY IF INITIAL INSTALLATION - NOT FOR UPGRADE)
then right click on one of the  selected files and choose Move To, click on Documents in the left panel, then the SKCCLogger folder, press the Select button at the bottom right of the window to move the files.

5. While still in the File application navigate back to the to the SKCCLogger_Linux folder in your Home directory.

6. Right click on the SKCCLogger file and choose properties, select the permissions tab and check the execute box.

7. Double click the SKCCLogger file here to start the program (Optionally right click on the SKCCLogger file and choose Make Link, then drag this file to your desktop to have a launcher there)

8. To enable rig control you must add your user ID to the dialout group - Open the terminal application and execute the following command.:
sudo adduser {username} dialout

9. After adding user, you must either reboot or log out and log back in to getiing shange to take affect.

Notes:
=====
PLEASE keep your log files in the SKCCLogger/Logs folder. 

Initial installation steps above added a logfile.adi to the Logs folder.



These instructions are written for a installation on Ubuntu 16.04 LTS .. They may or may not work 
with other LINUX distributions.
